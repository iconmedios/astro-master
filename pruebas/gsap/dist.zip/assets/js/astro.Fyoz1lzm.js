/* empty css               */
import { c as createAstro, a as createComponent, r as renderTemplate, m as maybeRenderHead, b as addAttribute, s as spreadAttributes, d as renderSlot, e as renderComponent, f as renderHead } from './astro.ai4AEc2w.js';
import 'kleur/colors';
import 'html-escaper';
import 'clsx';
/* empty css               */

const $$Astro$c = createAstro("https://sitio.com");
const $$StyleBase = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$c, $$props, $$slots);
  Astro2.self = $$StyleBase;
  return renderTemplate``;
}, "C:/Users/iconm/OneDrive/Escritorio/astro-master/src/components/theme/StyleBase.astro", void 0);

const menus = {
	main: [
		{
			title: "Inicio",
			link: "/"
		},
		{
			title: "Acerca de",
			link: "/acerca"
		},
		{
			title: "Servicios",
			link: "/servicios"
		},
		{
			title: "Productos",
			link: "/productos"
		},
		{
			title: "Contacto",
			link: "/contacto"
		}
	],
	services: [
		{
			title: "Stands Institucionales",
			link: "/stands"
		},
		{
			title: "Módulos de Registro",
			link: "/escenografias"
		},
		{
			title: "Arcos de Bienvenida",
			link: "/ferias-y-exposiciones"
		},
		{
			title: "Administración de ferias",
			link: "/produccion-de-audiovisual"
		},
		{
			title: "Aviso de Privacidad",
			link: "/aviso-de-privacidad"
		}
	],
	legal: [
		{
			name: "Aviso de Privacidad",
			link: "/aviso-de-privacidad"
		},
		{
			name: "Descargar Presentación",
			link: "https://www.standout.com.mx/wp-content/uploads/2020/05/STANDOUT_PRESENTA_V1.pdf"
		}
	]
};

const $$Astro$b = createAstro("https://sitio.com");
const $$LinkBase = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$b, $$props, $$slots);
  Astro2.self = $$LinkBase;
  const { href, class: className, ...props } = Astro2.props;
  const { pathname } = Astro2.url;
  const isActive = href === pathname || href === pathname.replace(/\/$/, "");
  return renderTemplate`${maybeRenderHead()}<a${addAttribute(href, "href")}${addAttribute([className, { active: isActive }], "class:list")}${spreadAttributes(props)} data-astro-cid-khtixdj5> ${renderSlot($$result, $$slots["default"])} </a> `;
}, "C:/Users/iconm/OneDrive/Escritorio/astro-master/src/components/theme/LinkBase.astro", void 0);

const $$Astro$a = createAstro("https://sitio.com");
const $$MainMenu = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$a, $$props, $$slots);
  Astro2.self = $$MainMenu;
  const menu = menus.main;
  const { class: menuClass } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<ul${addAttribute(menuClass, "class")}> ${menu.map(({ title, link }) => renderTemplate`<li>${renderComponent($$result, "HeaderLink", $$LinkBase, { "href": link }, { "default": ($$result2) => renderTemplate`${title}` })}</li>`)} </ul>`;
}, "C:/Users/iconm/OneDrive/Escritorio/astro-master/src/components/theme/MainMenu.astro", void 0);

const $$Astro$9 = createAstro("https://sitio.com");
const $$Logo = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$9, $$props, $$slots);
  Astro2.self = $$Logo;
  return renderTemplate`${maybeRenderHead()}<a href="/">LOGO</a>`;
}, "C:/Users/iconm/OneDrive/Escritorio/astro-master/src/components/theme/Logo.astro", void 0);

const $$Astro$8 = createAstro("https://sitio.com");
const $$NavIcon = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$8, $$props, $$slots);
  Astro2.self = $$NavIcon;
  return renderTemplate` ${maybeRenderHead()}<button class="flex lg:hidden active w-32px h-32px bg-blue relative overflow-hidden " data-astro-cid-drqx3ebz> <span class="block h-8px hover:h-12px" data-astro-cid-drqx3ebz></span> </button> `;
}, "C:/Users/iconm/OneDrive/Escritorio/astro-master/src/components/icons/NavIcon.astro", void 0);

const $$Astro$7 = createAstro("https://sitio.com");
const $$Header = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$7, $$props, $$slots);
  Astro2.self = $$Header;
  return renderTemplate`${maybeRenderHead()}<header id="navbar" data-astro-cid-3ef6ksr2> <div class="container flex items-center justify-between " data-astro-cid-3ef6ksr2> ${renderComponent($$result, "Logo", $$Logo, { "class": "logo", "data-astro-cid-3ef6ksr2": true })} <nav id="nav-menu" data-astro-cid-3ef6ksr2> <!-- <div class="fondo-bar"></div>  --> ${renderComponent($$result, "MainMenu", $$MainMenu, { "class": "menu-navbar flex gap-4", "data-astro-cid-3ef6ksr2": true })} </nav> ${renderComponent($$result, "NavIcon", $$NavIcon, { "data-astro-cid-3ef6ksr2": true })} </div> </header> `;
}, "C:/Users/iconm/OneDrive/Escritorio/astro-master/src/components/Header.astro", void 0);

const $$Astro$6 = createAstro("https://sitio.com");
const $$Footer = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$6, $$props, $$slots);
  Astro2.self = $$Footer;
  return renderTemplate`${maybeRenderHead()}<footer id="footer" class="seccion-base contrast w-full" data-astro-cid-sz7xmlte> <div class="container" data-astro-cid-sz7xmlte> <div class="grid lg:grid-cols-5 md:grid-cols-3 gap-12" data-astro-cid-sz7xmlte> <div class="py-4 md:py-8 lg:py-16 col-span-2" data-astro-cid-sz7xmlte> <h5 data-astro-cid-sz7xmlte>Servicios</h5> <p data-astro-cid-sz7xmlte>
lorem interdum. Quisque erat sem, pellentesque quis auctor
                    ut, faucibus et dui. Etiam et aliquam ligula. Integer ut
                    tincidunt enim. Aliquam erat volutpat. Nunc finibus, neque
                    in tincidunt semper, massa mauris ullamcorper magna, vel
                    tristique neque sapien sit amet nisl.
</p> </div> <div class="py-4 md:py-8 lg:py-16" data-astro-cid-sz7xmlte> <h5 data-astro-cid-sz7xmlte>Servicios</h5> ${renderComponent($$result, "MainMenu", $$MainMenu, { "class": "footer-class", "data-astro-cid-sz7xmlte": true })} </div> <div class="py-4 md:py-8 lg:py-16" data-astro-cid-sz7xmlte> <h5 data-astro-cid-sz7xmlte>Información</h5> ${renderComponent($$result, "MainMenu", $$MainMenu, { "class": "footer-class", "data-astro-cid-sz7xmlte": true })} </div> <div class="py-4 md:py-8 lg:py-16" data-astro-cid-sz7xmlte> <h5 data-astro-cid-sz7xmlte>Contacto</h5> ${renderComponent($$result, "MainMenu", $$MainMenu, { "class": "footer-class", "data-astro-cid-sz7xmlte": true })} </div> </div> </div> </footer> <p class="text-center w-86% mx-auto py-8" data-astro-cid-sz7xmlte> <span data-astro-cid-sz7xmlte>STAND</span>OUT | STANDS & STAGES ® TODOS LOS
    DERECHOS RESERVADOS
</p> <div class="bg-brand-base sm:bg-black md:bg-brand-red lg:bg-brand-gray xl:bg-brand-base h-2" data-astro-cid-sz7xmlte></div> `;
}, "C:/Users/iconm/OneDrive/Escritorio/astro-master/src/components/Footer.astro", void 0);

const $$Astro$5 = createAstro("https://sitio.com");
const $$SEO = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$5, $$props, $$slots);
  Astro2.self = $$SEO;
  const title = Astro2.props.title + " | Standout\xAE Stands & Stages";
  const description = Astro2.props.description || "Dise\xF1amos el poder de atracci\xF3n de tu marca\xAE";
  const canonicalURL = Astro2.props.canonicalURL || new URL(Astro2.url.pathname, Astro2.site);
  const image = new URL(Astro2.props.image || "/images/social.png", Astro2.site);
  return renderTemplate`<!-- Global Metadata --><meta charset="utf-8"><meta name="viewport" content="width=device-width"><meta name="author" content="iconmedios.com"><link rel="icon" type="image/png" href="/images/standout_ico.svg"><!-- Primary Meta Tags --><title>${title}</title><meta name="title"${addAttribute(title, "content")}><meta name="description"${addAttribute(description, "content")}><link rel="canonical"${addAttribute(canonicalURL, "href")}><!-- Generator --><meta name="generator"${addAttribute(Astro2.generator, "content")}><!-- Open Graph / Facebook --><meta property="og:type" content="website"><meta property="og:url"${addAttribute(canonicalURL, "content")}><meta property="og:title"${addAttribute(title, "content")}><meta property="og:description"${addAttribute(description, "content")}><meta property="og:image"${addAttribute(image, "content")}><!-- Twitter --><meta property="twitter:card" content="summary_large_image"><meta property="twitter:url"${addAttribute(canonicalURL, "content")}><meta property="twitter:title"${addAttribute(title, "content")}><meta property="twitter:description"${addAttribute(description, "content")}><meta property="twitter:image"${addAttribute(image, "content")}><!-- For Demonstration of the themes --><!-- Google Analytics -->`;
}, "C:/Users/iconm/OneDrive/Escritorio/astro-master/src/components/SEO.astro", void 0);

const $$Astro$4 = createAstro("https://sitio.com");
const $$ThemeSwicher = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$4, $$props, $$slots);
  Astro2.self = $$ThemeSwicher;
  return renderTemplate`${maybeRenderHead()}<div class="fixed top-14 right-0 z-2" data-astro-cid-zuvkqgix> <span class="theme-btn bg-white" name-theme="light" data-astro-cid-zuvkqgix></span> <span class="theme-btn bg-black" name-theme="dark" data-astro-cid-zuvkqgix></span> <span class="theme-btn bg-orange" name-theme="salmon" data-astro-cid-zuvkqgix></span> </div>  `;
}, "C:/Users/iconm/OneDrive/Escritorio/astro-master/src/components/theme/ThemeSwicher.astro", void 0);

const $$Astro$3 = createAstro("https://sitio.com");
const $$ToggleButton = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$3, $$props, $$slots);
  Astro2.self = $$ToggleButton;
  return renderTemplate`${maybeRenderHead()}<button class="toggle-button">Toggle</button>`;
}, "C:/Users/iconm/OneDrive/Escritorio/astro-master/src/components/widgets/ToggleButton.astro", void 0);

var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(raw || cooked.slice()) }));
var _a;
const $$Astro$2 = createAstro("https://sitio.com");
const $$Layout = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$2, $$props, $$slots);
  Astro2.self = $$Layout;
  const { seo } = Astro2.props;
  return renderTemplate(_a || (_a = __template(['<html lang="es" data-theme="ligth"> <head>', "", "</head> <body> ", " <main> ", " ", " </main> ", " ", '  <script src="/assets/js/fslightbox.js"><\/script> <script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/3.2.1/anime.min.js"><\/script> </body> </html> ', ""])), renderComponent($$result, "SEO", $$SEO, { ...seo }), renderHead(), renderComponent($$result, "Header", $$Header, {}), renderSlot($$result, $$slots["default"]), renderComponent($$result, "ToggleButton", $$ToggleButton, {}), renderComponent($$result, "Footer", $$Footer, {}), renderComponent($$result, "ThemeSwicher", $$ThemeSwicher, {}), renderComponent($$result, "StyleBase", $$StyleBase, {}));
}, "C:/Users/iconm/OneDrive/Escritorio/astro-master/src/layouts/Layout.astro", void 0);

const $$Astro$1 = createAstro("https://sitio.com");
const $$LayoutPage = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$LayoutPage;
  const { seo, titlepage, subtitle } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "seo": seo }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<section class="seccion-base surface"> <div class="container pt-12"> <h1>${titlepage}</h1> <p>${subtitle}</p> </div> </section> ${renderSlot($$result2, $$slots["default"])} ` })}`;
}, "C:/Users/iconm/OneDrive/Escritorio/astro-master/src/layouts/LayoutPage.astro", void 0);

const $$Astro = createAstro("https://sitio.com");
const $$Acerca = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Acerca;
  const datapage = {
    titlePage: "Acerca de ",
    description: " Subtitulo General"
  };
  const seo = {
    title: datapage.titlePage,
    description: datapage.description
  };
  return renderTemplate`${renderComponent($$result, "LayoutPage", $$LayoutPage, { "seo": seo, "titlepage": datapage.titlePage, "subtitle": datapage.description }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<section class="seccion-base pale"> <div class="container"> <h3>Pale</h3> </div> </section> <section class="seccion-base contrast"> <div class="container"> <h3>Contrast</h3> </div> </section> <section class="seccion-base surface"> <div class="container"> <h3>Surface</h3> </div> </section> <section class="seccion-base"> <div class="container"> <h3>Normal</h3> </div> </section> ` })}`;
}, "C:/Users/iconm/OneDrive/Escritorio/astro-master/src/pages/acerca.astro", void 0);

const $$file = "C:/Users/iconm/OneDrive/Escritorio/astro-master/src/pages/acerca.astro";
const $$url = "/acerca";

const acerca = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
	__proto__: null,
	default: $$Acerca,
	file: $$file,
	url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

export { $$LayoutPage as $, $$Layout as a, acerca as b };
