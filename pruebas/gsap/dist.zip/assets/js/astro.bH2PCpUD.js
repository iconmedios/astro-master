/* empty css               */
import { c as createAstro, a as createComponent, r as renderTemplate, e as renderComponent, m as maybeRenderHead } from './astro.ai4AEc2w.js';
import 'kleur/colors';
import 'html-escaper';
import 'clsx';
import { $ as $$LayoutPage } from './astro.Fyoz1lzm.js';

const $$Astro = createAstro("https://sitio.com");
const $$Servicios = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Servicios;
  const datapage = {
    titlePage: "Servicios",
    description: " Subtitulo General"
  };
  const seo = {
    title: datapage.titlePage,
    description: datapage.description
  };
  return renderTemplate`${renderComponent($$result, "LayoutPage", $$LayoutPage, { "seo": seo, "titlepage": datapage.titlePage, "subtitle": datapage.description }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<section class="seccion-base pale"> <div class="container"> <h2>${datapage.titlePage} Custom</h2> <p>${datapage.description}</p> </div> </section> ` })}`;
}, "C:/Users/iconm/OneDrive/Escritorio/astro-master/src/pages/servicios.astro", void 0);

const $$file = "C:/Users/iconm/OneDrive/Escritorio/astro-master/src/pages/servicios.astro";
const $$url = "/servicios";

export { $$Servicios as default, $$file as file, $$url as url };
