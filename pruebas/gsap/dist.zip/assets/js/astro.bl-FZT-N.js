/* empty css               */
import { c as createAstro, a as createComponent, r as renderTemplate, e as renderComponent, m as maybeRenderHead } from './astro.ai4AEc2w.js';
import 'kleur/colors';
import 'html-escaper';
import 'clsx';
import { $ as $$LayoutPage } from './astro.Fyoz1lzm.js';

const $$Astro = createAstro("https://sitio.com");
const $$Contacto = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Contacto;
  const datapage = {
    titlePage: "Cont\xE1ctenos",
    description: " Subtitulo General de productos"
  };
  console.log(datapage);
  const seo = {
    title: datapage.titlePage,
    description: datapage.description
  };
  return renderTemplate`${renderComponent($$result, "LayoutPage", $$LayoutPage, { "seo": seo, "titlepage": datapage.titlePage, "subtitle": datapage.description }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<section class="seccion-base"> <div class="container"> <h3>${datapage.titlePage} Custom</h3> <p>${datapage.description}</p> </div> </section> ` })}`;
}, "C:/Users/iconm/OneDrive/Escritorio/astro-master/src/pages/contacto.astro", void 0);

const $$file = "C:/Users/iconm/OneDrive/Escritorio/astro-master/src/pages/contacto.astro";
const $$url = "/contacto";

export { $$Contacto as default, $$file as file, $$url as url };
