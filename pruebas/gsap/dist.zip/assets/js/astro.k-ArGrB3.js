/* empty css               */
import { c as createAstro, a as createComponent, r as renderTemplate, m as maybeRenderHead, e as renderComponent } from './astro.ai4AEc2w.js';
import 'kleur/colors';
import 'html-escaper';
import 'clsx';
/* empty css               */
import { a as $$Layout } from './astro.Fyoz1lzm.js';

const $$Astro$1 = createAstro("https://sitio.com");
const $$IconTheme = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$IconTheme;
  return renderTemplate`${maybeRenderHead()}<button id="animateButton" data-astro-cid-24pkezpp>Boton</button> <div class="box" data-astro-cid-24pkezpp></div> `;
}, "C:/Users/iconm/OneDrive/Escritorio/astro-master/src/components/theme/IconTheme.astro", void 0);

const $$Astro = createAstro("https://sitio.com");
const $$Index = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Index;
  const datapage = {
    titlePage: "Ferias y Exposiciones",
    description: "Administraci\xF3n de Ferias y/o Exposiciones Comerciales"
  };
  const seo = {
    title: datapage.titlePage,
    description: datapage.description
  };
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "seo": seo }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<section class="seccion-base"> <div class="container h-50vh grid ic"> <div> <h1 class="brand">${datapage.titlePage} Custom</h1> <p>${datapage.description}</p> </div> <div> ${renderComponent($$result2, "IconTheme", $$IconTheme, {})} </div> </div> </section> <section class="seccion-base surface"> <div class="container"> <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio.</p> </div> </section> ` })}`;
}, "C:/Users/iconm/OneDrive/Escritorio/astro-master/src/pages/index.astro", void 0);

const $$file = "C:/Users/iconm/OneDrive/Escritorio/astro-master/src/pages/index.astro";
const $$url = "";

export { $$Index as default, $$file as file, $$url as url };
